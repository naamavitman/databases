SELECT p.name, fc.amount
FROM financial_contribution fc
JOIN contribution c ON fc.Donation_number = c.Donation_number
JOIN donor d ON c.person_Id = d.person_Id
JOIN person p ON d.person_Id = p.person_Id
WHERE fc.amount > &amount_threshold;

SELECT p.person_Id, p.name, p.Email
FROM person p
JOIN donor d ON p.person_Id = d.person_Id
WHERE p.name LIKE '%' || '&donor_name' || '%';

SELECT d.person_Id, p.name, SUM(fc.amount) AS total_amount
FROM donor d
JOIN contribution c ON d.person_Id = c.person_Id
JOIN financial_contribution fc ON c.Donation_number = fc.Donation_number
JOIN person p ON d.person_Id = p.person_Id
GROUP BY d.person_Id, p.name
HAVING SUM(fc.amount) > &min_amount;

DEFINE min_amount = 150.00;

SELECT d.person_Id, p.name, SUM(fc.amount) AS total_amount
FROM donor d
JOIN contribution c ON d.person_Id = c.person_Id
JOIN financial_contribution fc ON c.Donation_number = fc.Donation_number
JOIN person p ON d.person_Id = p.person_Id
GROUP BY d.person_Id, p.name
HAVING SUM(fc.amount) > &min_amount;

