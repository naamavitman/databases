
create table large_donors (
  person_id int primary key,
  name varchar2(100),
  total_amount number(10, 2),
  gift varchar2(50)
);

